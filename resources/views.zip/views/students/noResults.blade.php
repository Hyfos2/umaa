@extends('internal.welcome')
@section('content')
    <div class="row">
        <div class="col-md-3">

        </div>
        <div class="col-md-5">
            <div class="card" id="poorStudents">
                <div class="card-body ">
                    <div class="card-block report">

				<span style="text-align: center;">
					<strong><h6>Results are unavailable </h6></strong>
				</span>


                        </div>
                    </div>
                </div>
            </div>

        </div>

        <div class="col-md-3">

        </div>
    </div>
@stop