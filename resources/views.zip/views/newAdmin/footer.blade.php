
<footer class="main-footer footerDiv">
    <div class="pull-right hidden-xs">
        <b>Version</b> 0.0.1
    </div>
    <strong>Copyright &copy; {{currentYear()}}  <i>Powered By <a href="javascript:void(0);">Thomas Schools System</a></i>.</strong> All rights reserved.
</footer>