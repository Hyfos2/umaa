
<div id="cambridgeSubjects" class="tab-pane fade in active">
    <div class="block-area grade" id="responsiveTable">
        <div class="table-responsive overflow">
            <table class="table tile table-striped" id="cambridgeSubjectsTable">
                <thead>
                <tr>
                    <th>Record Id</th>
                    <th>Subject Code</th>
                    <th>Subject Name</th>
                    <th>Created At</th>
                    <th>Action</th>
                </tr>
                </thead>
            </table>

        </div>
    </div>

</div>




