<div id="grade-2" class="tab-pane fade">

    <div class="block-area grade" id="responsiveTable">
        <div class="table-responsive overflow">
            <table class="table tile table-striped" id="grade-2Table">
                <thead>
                <tr>
                    <th>Record Id</th>
                    <th>Teacher Name</th>
                    <th>Teacher Surname</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
                </thead>
            </table>
        </div>
    </div>


</div>