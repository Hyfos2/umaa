

<footer class="bdT ta-c p-30 lh-0 fsz-sm c-grey-600">
    <span>Copyright © {{currentYear()}} Powered by <a href="javascript:void(0)" target="_blank" title="Colorlib">Brian Technologies</a>. All rights reserved.</span><!-- Global site tag (gtag.js) - Google Analytics -->
    {{--<script async="" src="{{asset('js/js')}}">--}}
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());

        gtag('config', 'UA-23581568-13');
    </script>
</footer>