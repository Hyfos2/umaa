<div id="formstudents-1" class="tab-pane fade in active">
    <div class="block-area grade" id="responsiveTable">
        <div class="table-responsive overflow">
            <table class="table tile table-striped" id="form-1studentTable">
                <thead>
                <tr>
                    <th>Record Id</th>
                    <th>Student Name</th>
                    <th>Student Surname</th>
                    <th>Email</th>
                    <th>Action</th>
                </tr>
                </thead>
            </table>
        </div>
    </div>

</div>




