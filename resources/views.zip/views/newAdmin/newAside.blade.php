<div class="sidebar">
    <div class="sidebar-inner">
        <div class="sidebar-logo">
            <div class="peers ai-c fxw-nw">
                <div class="peer peer-greed">
                    <a class="sidebar-link td-n" href="javascript:void(0);">
                        <div class="peers ai-c fxw-nw">
                            <div class="peer">
                                <div class="logo">
                                    <img src="{{asset('img/logo.png')}}" alt="">
                                </div>
                            </div>
                            <div class="peer peer-greed">
                                <h5 class="lh-1 mB-0 logo-text">Admin</h5>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="peer">
                    <div class="mobile-toggle sidebar-toggle">
                        <a href="javascript:void(0)" class="td-n">
                            <i class="ti-arrow-circle-left">
                            </i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <ul class="sidebar-menu scrollable pos-r ps">
            <li class="nav-item mT-30 active">
                <a class="sidebar-link" href="{{url('adminpnl')}}">
                        {{--<span class="icon-holder">--}}
                            {{--<i class="c-blue-500 ti-home">--}}

                            {{--</i> </span>--}}
                    <span class="title">Home</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="sidebar-link" href="{{url('accounts')}}">
                        {{--<span class="icon-holder">--}}
                            {{--<i class="c-brown-500 ti-book">--}}

                            {{--</i>--}}
                        {{--</span>--}}
                    <span class="title">Accounts</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="sidebar-link" href="{{url('addAdmin')}}">
                        {{--<span class="icon-holder">--}}
                            {{--<i class="c-deep-orange-500 ti-user">--}}
                            {{--</i> </span>--}}
                    <span class="title">Admin Users</span>
                </a>
            </li>


            <li class="nav-item">
                <a class="sidebar-link" href="{{url('calendar')}}">
                        {{--<span class="icon-holder">--}}
                            {{--<i class="c-deep-orange-500 ti-calendar">--}}

                            {{--</i> </span>--}}
                    <span class="title">Calendar</span>
                </a>
            </li>

            <li class="nav-item">
                <a class="sidebar-link" href="{{url('subject')}}">
                        {{--<span class="icon-holder">--}}
                            {{--<i class="c-deep-orange-500 ti-calendar">--}}

                            {{--</i> </span>--}}
                    <span class="title">Subjects</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="sidebar-link" href="{{url('sport')}}">
                        {{--<span class="icon-holder">--}}
                            {{--<i class="c-deep-orange-500 ti-calendar">--}}

                            {{--</i> </span>--}}
                    <span class="title">Sports</span>
                </a>
            </li>

            {{--<li class="nav-item">--}}
                {{--<a class="sidebar-link" href="https://colorlib.com/polygon/adminator/chat.html">--}}
                        {{--<span class="icon-holder">--}}
                            {{--<i class="c-deep-purple-500 ti-comment-alt">--}}

                            {{--</i> </span>--}}
                    {{--<span class="title">Chat</span></a></li>--}}
            {{--<li class="nav-item"><a class="sidebar-link" href="https://colorlib.com/polygon/adminator/charts.html">--}}
                    {{--<span class="icon-holder"><i class="c-indigo-500 ti-bar-chart"></i> </span><span class="title">Charts</span></a></li>--}}
            {{--<li class="nav-item"><a class="sidebar-link" href="https://colorlib.com/polygon/adminator/forms.html">--}}
                    {{--<span class="icon-holder"><i class="c-light-blue-500 ti-pencil"></i> </span><span class="title">Forms</span></a></li>--}}
            {{--<li class="nav-item dropdown"><a class="sidebar-link" href="https://colorlib.com/polygon/adminator/ui.html">--}}
                    {{--<span class="icon-holder"><i class="c-pink-500 ti-palette"></i> </span>--}}
                    {{--<span class="title">UI Elements</span></a></li>--}}
            {{--<li class="nav-item dropdown"><a class="dropdown-toggle" href="javascript:void(0);">--}}
                    {{--<span class="icon-holder"><i class="c-orange-500 ti-layout-list-thumb"></i> </span>--}}
                    {{--<span class="title">Tables</span>--}}
                    {{--<span class="arrow"><i class="ti-angle-right"></i></span>--}}
                {{--</a><ul class="dropdown-menu">--}}
                    {{--<li><a class="sidebar-link" href="https://colorlib.com/polygon/adminator/basic-table.html">Basic Table</a></li><li>--}}
                        {{--<a class="sidebar-link" href="https://colorlib.com/polygon/adminator/datatable.html">Data Table</a></li>--}}
                {{--</ul>--}}
            {{--</li>--}}
            {{--<li class="nav-item dropdown">--}}
                {{--<a class="dropdown-toggle" href="javascript:void(0);">--}}
                        {{--<span class="icon-holder">--}}
                            {{--<i class="c-purple-500 ti-map">--}}

                            {{--</i> </span>--}}
                    {{--<span class="title">Maps</span>--}}
                    {{--<span class="arrow"><i class="ti-angle-right"></i></span></a>--}}
                {{--<ul class="dropdown-menu"><li><a href="https://colorlib.com/polygon/adminator/google-maps.html">Google Map</a></li>--}}
                    {{--<li><a href="https://colorlib.com/polygon/adminator/vector-maps.html">Vector Map</a></li></ul></li>--}}
            {{--<li class="nav-item dropdown">--}}
                {{--<a class="dropdown-toggle" href="javascript:void(0);">--}}
                    {{--<span class="icon-holder"><i class="c-red-500 ti-files"></i> </span>--}}
                    {{--<span class="title">Pages</span>--}}
                    {{--<span class="arrow"><i class="ti-angle-right"></i></span>--}}
                {{--</a>--}}
                {{--<ul class="dropdown-menu"><li>--}}
                        {{--<a class="sidebar-link" href="https://colorlib.com/polygon/adminator/404.html">404</a></li>--}}
                    {{--<li><a class="sidebar-link" href="https://colorlib.com/polygon/adminator/500.html">500</a></li>--}}
                    {{--<li><a class="sidebar-link" href="https://colorlib.com/polygon/adminator/signin.html">Sign In</a></li>--}}
                    {{--<li><a class="sidebar-link" href="https://colorlib.com/polygon/adminator/signup.html">Sign Up</a></li>--}}
                {{--</ul>--}}
            {{--</li>--}}
            <li class="nav-item dropdown">
                <a class="dropdown-toggle" href="javascript:void(0);">
                    {{--<span class="icon-holder"><i class="c-teal-500 ti-view-list-alt"></i></span>--}}
                    <span class="title">Institute-Campuses</span>
                    <span class="arrow"><i class="ti-angle-right"></i></span></a>
                <ul class="dropdown-menu">
                    {{--<li class="nav-item dropdown"><a href="javascript:void(0);">--}}
                            {{--<span>Primary School</span>--}}
                            {{--<span class="arrow"><i class="ti-angle-right"></i></span>--}}
                        {{--</a>--}}
                        {{--<ul class="dropdown-menu">--}}
                            {{--<li><a href="{{url('primarystdnt')}}">Students</a></li>--}}
                            {{--<li><a href="{{url('primarytchr')}}">Teachers</a></li>--}}
                        {{--</ul>--}}
                    {{--</li>--}}
                    <li class="nav-item dropdown"><a href="javascript:void(0);">
                            <span>Secondary School</span>
                            {{--<span class="arrow"><i class="ti-angle-right"></i></span>--}}
                        </a>
                        <ul class="dropdown-menu">
                            <li><a href="{{url('stdnts')}}">Students</a></li>
                            <li><a href="{{url('tcher')}}">Teachers</a></li>
                        </ul>
                    </li>
                </ul>
            </li>




            <li class="nav-item">
                <a class="sidebar-link" href="{{url('users')}}">
                        {{--<span class="icon-holder">--}}
                            {{--<i class="c-deep-orange-500 ti-user">--}}
                            {{--</i> </span>--}}
                    <span class="title">User Logs</span>
                </a>
            </li>


            <div class="ps__rail-x" style="left: 0px; bottom: 0px;">
                <div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;">

                </div>
            </div>
            <div class="ps__rail-y" style="top: 0px; right: 0px;">
                <div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 0px;">

                </div>
            </div>
        </ul>
    </div>
</div>