<footer class="site-footer">
            <div class="footer-inner bg-white">
                <div class="row">
                    <div class="col-sm-6">
                        Copyright &copy; 2018 All Solutions Softwares.Inc
                    </div>
                    <div class="col-sm-6 text-right">
                       <a href="javascript:void(0);">Umaa Institute</a>
                    </div>
                </div>
            </div>
        </footer>