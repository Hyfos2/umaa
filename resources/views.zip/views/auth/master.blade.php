<!DOCTYPE html>
<html>
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
@include('title')
<link href="{{asset('css/loginCss.css')}}" rel="stylesheet">
<body class="app">
@yield('content')
</body>
</html>